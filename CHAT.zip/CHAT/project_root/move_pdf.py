import os
import shutil

# Define source folder (where the PDFs are currently stored)
source_directory = "C:/Users/adgup/Downloads/pdff"  # Change this to your actual folder

# Define destination folder (inside your project)
destination_directory = "data/pdfs"

# Ensure destination directory exists
os.makedirs(destination_directory, exist_ok=True)

# Move PDFs from source to destination
def move_pdfs():
    try:
        pdf_files = [f for f in os.listdir(source_directory) if f.endswith(".pdf")]
        
        for pdf in pdf_files:
            source_path = os.path.join(source_directory, pdf)
            destination_path = os.path.join(destination_directory, pdf)

            if not os.path.exists(destination_path):  # Avoid overwriting
                shutil.move(source_path, destination_path)
                print(f"Moved {pdf} to {destination_directory}")
            else:
                print(f"Skipped {pdf}, already exists in {destination_directory}")

    except Exception as e:
        print(f"Error moving PDFs: {str(e)}")

# Call function to move PDFs
move_pdfs()
