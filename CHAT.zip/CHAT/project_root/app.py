import os
from flask import Flask, request, jsonify
from utils.pdf_processing import extract_text_from_pdfs
from utils.embedding import generate_embeddings
from utils.faiss_index import create_faiss_index, retrieve_relevant_chunks
from utils.llm_response import generate_response
import faiss

app = Flask(__name__)

# Configurations
PDF_DIR = "data/pdfs"
MODEL_NAME = 'sentence-transformers/all-MiniLM-L6-v2'

# Load PDFs and process embeddings
pdf_texts = extract_text_from_pdfs(PDF_DIR)
chunks, embeddings = generate_embeddings(pdf_texts, MODEL_NAME)
faiss_index = create_faiss_index(embeddings)

@app.route('/query', methods=['POST'])
def query_pdf():
    data = request.json
    query = data.get('query', '').strip()
    
    if not query:
        return jsonify({"error": "Query cannot be empty."}), 400
    
    retrieved_chunks = retrieve_relevant_chunks(query, faiss_index, chunks, MODEL_NAME)
    response = generate_response(retrieved_chunks, query)
    
    return jsonify({"response": response}), 200

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
