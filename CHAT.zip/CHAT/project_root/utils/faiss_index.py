import faiss

def create_faiss_index(embeddings):
    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings)
    return index

def retrieve_relevant_chunks(query, index, chunks, model_name, top_k=5):
    from transformers import AutoTokenizer, AutoModel
    import numpy as np
    
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name)
    
    inputs = tokenizer(query, return_tensors="pt", truncation=True, padding=True)
    query_embedding = model(**inputs).last_hidden_state.mean(dim=1).detach().numpy()
    
    distances, indices = index.search(query_embedding, top_k)
    return [chunks[i] for i in indices[0]]
