import os
from pdfreader import PDFDocument, SimplePDFViewer, PageDoesNotExist

def extract_text_from_pdfs(pdf_dir):
    pdf_texts = []
    
    for filename in os.listdir(pdf_dir):
        if filename.endswith(".pdf"):
            with open(os.path.join(pdf_dir, filename), "rb") as file:
                text = ""
                viewer = SimplePDFViewer(file)
                page_number = 1
                while True:
                    try:
                        viewer.navigate(page_number)
                        viewer.render()
                        text += " ".join(viewer.canvas.strings) + "\n"
                        page_number += 1
                    except PageDoesNotExist:
                        break
                pdf_texts.append(text)
    
    return pdf_texts

