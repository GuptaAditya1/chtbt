import numpy as np
import torch
from transformers import AutoTokenizer, AutoModel

def generate_embeddings(texts, model_name):
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name)
    
    chunks = []
    embeddings = []

    for text in texts:
        words = text.split()
        text_chunks = [' '.join(words[i:i + 500]) for i in range(0, len(words), 500)]
        chunks.extend(text_chunks)
        
        for chunk in text_chunks:
            inputs = tokenizer(chunk, return_tensors="pt", truncation=True, padding=True)
            outputs = model(**inputs)
            embeddings.append(outputs.last_hidden_state.mean(dim=1).detach().numpy())

    return chunks, np.vstack(embeddings).astype('float32')
