import re
from ollama import Client

def generate_response(retrieved_chunks, query, model_name="llama3.2:1b"):
    client = Client()
    context = " ".join(retrieved_chunks)
    
    prompt = (
        f"As a personal chat assistant, provide accurate and relevant information based only on the provided context in 2-3 sentences. "
        f"Limit the answer to 50 words, donot give answer out of the context. \n\nContext:{context}\n\nQuery: {query}"
    )
    
    response = client.generate(model=model_name, prompt=prompt)
    
    return clean_response(response['response'])

def clean_response(response):
    return re.sub(r'Reference:.*', '', response, flags=re.DOTALL).strip()
