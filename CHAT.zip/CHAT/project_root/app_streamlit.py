import streamlit as st
import requests

# Streamlit App Configuration
st.set_page_config(page_title="PDF Chatbot", page_icon="📄", layout="centered")

# Custom CSS for better styling
st.markdown(
    """
    <style>
        .stTextInput>div>div>input {
            font-size: 18px;
            padding: 10px;
        }
        .stButton>button {
            font-size: 16px;
            background-color: #0078ff;
            color: white;
            border-radius: 10px;
            padding: 10px;
        }
        .stButton>button:hover {
            background-color: #005fcc;
        }
    </style>
    """,
    unsafe_allow_html=True
)

# Header Section
st.markdown("<h1 style='text-align: center;'>📄 PDF Chatbot</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center; font-size:18px;'>Ask questions based on the uploaded PDFs.</p>", unsafe_allow_html=True)
st.divider()

# User Query Input
query = st.text_input("💬 Enter your question:", placeholder="Type your query here...")

# Submit Button
if st.button("🔍 Get Answer"):
    if query.strip():
        with st.spinner("⏳ Processing your request..."):
            response = requests.post("http://127.0.0.1:5000/query", json={"query": query})
            
            if response.status_code == 200:
                answer = response.json().get("response", "No response received.")
                st.success("✅ Answer Found!")
                st.markdown(f"<div style='background:#f0f8ff;padding:15px;border-radius:10px;font-size:16px;'><b>Answer:</b> {answer}</div>", unsafe_allow_html=True)
            else:
                st.error(f"❌ Error: {response.json().get('error', 'Unknown error')}")
    else:
        st.warning("⚠️ Please enter a query before submitting.")

# Footer
st.divider()
st.markdown("<p style='text-align: center; font-size:14px; color: gray;'>Developed by Aditya 🚀</p>", unsafe_allow_html=True)
