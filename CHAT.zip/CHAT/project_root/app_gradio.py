import gradio as gr
import requests

# Backend API endpoint
BACKEND_URL = "http://127.0.0.1:5000/query"

def query_pdf_gradio(query, history):
    response = requests.post(BACKEND_URL, json={"query": query})
    if response.status_code == 200:
        answer = response.json().get("response", "No response received.")
        history.append((query, answer))
        return "", history
    else:
        error_msg = "❌ Error: " + response.json().get("error", "Unknown error")
        return error_msg, history

# Define Gradio UI
with gr.Blocks(theme=gr.themes.Soft()) as iface:
    gr.Markdown("# 📄 **PDF Chatbot**")
    gr.Markdown("🚀 *Ask questions based on the uploaded PDFs and get relevant responses instantly.*")
    
    with gr.Row():
        query_input = gr.Textbox(label="💬 Enter your query:", placeholder="Type your question here...", interactive=True)
        submit_button = gr.Button("🔍 Get Answer", variant="primary")

    response_output = gr.Textbox(label="📝 Response", interactive=False)

    with gr.Accordion("📜 Chat History", open=False):
        history_output = gr.Chatbot(label="Conversation History")

    submit_button.click(query_pdf_gradio, inputs=[query_input, history_output], outputs=[response_output, history_output])

# Launch Gradio app
if __name__ == "__main__":
    iface.launch()
