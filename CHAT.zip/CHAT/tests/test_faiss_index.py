import unittest
import numpy as np
import faiss
from utils.faiss_index import build_faiss_index

class TestFAISSIndex(unittest.TestCase):
    def test_faiss_index(self):
        embeddings = np.random.rand(10, 384).astype("float32")  # Fake embeddings
        index = build_faiss_index(embeddings)
        
        self.assertIsInstance(index, faiss.IndexFlatL2)
        self.assertEqual(index.ntotal, 10)

if __name__ == "__main__":
    unittest.main()
