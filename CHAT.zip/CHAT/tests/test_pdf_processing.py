import os
import unittest
from utils.pdf_processing import extract_text_from_pdf

class TestPDFProcessing(unittest.TestCase):
    def test_extract_text(self):
        pdf_path = "data/pdfs/RESEARCH_PAPER.pdf"  # Ensure this file exists for testing
        if not os.path.exists(pdf_path):
            self.skipTest("Sample PDF not found")
        
        text = extract_text_from_pdf(pdf_path)
        self.assertIsInstance(text, str)
        self.assertGreater(len(text), 0)

if __name__ == "__main__":
    unittest.main()
