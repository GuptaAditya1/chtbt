import requests

url = "http://127.0.0.1:5000/query"
payload = {
    "query": "what is the topic of this paper"
}

try:
    response = requests.post(url, json=payload, timeout=500)  # Fixed: Corrected requests.post
    response.raise_for_status()  # Raises an error for HTTP errors (4xx, 5xx)
    
    print("Response:", response.json())  # Fixed: Corrected response.json()
    
except requests.exceptions.Timeout:
    print("Timeout: The request took too long to complete.")
except requests.exceptions.RequestException as e:
    print("Error:", e)

