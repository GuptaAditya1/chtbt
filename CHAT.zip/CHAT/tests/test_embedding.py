import unittest
import numpy as np
from transformers import AutoTokenizer, AutoModel
from utils.embedding import generate_embeddings

class TestEmbedding(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model_name = "sentence-transformers/all-MiniLM-L6-v2"
        cls.tokenizer = AutoTokenizer.from_pretrained(cls.model_name)
        cls.model = AutoModel.from_pretrained(cls.model_name)

    def test_generate_embeddings(self):
        chunks = ["This is a test chunk.", "Another chunk for testing."]
        embeddings = generate_embeddings(chunks, self.model, self.tokenizer)
        
        self.assertIsInstance(embeddings, np.ndarray)
        self.assertEqual(embeddings.shape[0], len(chunks))

if __name__ == "__main__":
    unittest.main()
